ready_optimize_text = font.render(
    "Ready to optimize!", True, (121, 63, 43), bgcolor)

draw_centered_surface(screen, ready_optimize_text, 350)