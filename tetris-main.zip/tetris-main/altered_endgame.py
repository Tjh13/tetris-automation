if game_over and TopReached or paused:
    continue

